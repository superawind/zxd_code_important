import math
from typing import List, Optional, Tuple, Union
import torch
import torch.nn.functional as F
import torch.utils.checkpoint
from torch import nn
import os
import pandas as pd

from torch.utils.data import IterableDataset, Dataset
import json
import numpy as np
from transformers import  PreTrainedModel
from transformers.modeling_outputs import CausalLMOutputWithPast
from transformers import PretrainedConfig
from transformers import Trainer, TrainingArguments, AutoModelForCausalLM, AutoTokenizer, DefaultDataCollator, DataCollatorForTokenClassification, AutoConfig
from dataset import SFTDataset, LLMDataset
from transformers import AutoTokenizer, AutoModelForCausalLM, AutoConfig
import torch
from pretrain import LLM, Config


if __name__ == '__main__':
    # 注册信息，自定义结构，预训练 定义的模型类型 (config.json 中 的 model_type) 为 moe_model, 模型架构（config.json 中的architectures）为 LLM
    # transformers 中并没有定义我们自定义的 模型的一些结构信息，因此必须添加注册
    AutoConfig.register('moe_model', Config)
    AutoModelForCausalLM.register(Config, LLM)
    model = AutoModelForCausalLM.from_pretrained('/mnt/code/zhaoxudong03/RL/verl_base_zxd/01_llm_releate/save_models/qwen3_next/pretrain', trust_remote_code=True)
    print(model)
    print(f'模型参数量为: {sum(p.numel() for p in model.parameters() if p.requires_grad)}')
    
    data_collator = DefaultDataCollator()
    tokenizer = AutoTokenizer.from_pretrained('/mnt/code/zhaoxudong03/RL/verl_base_zxd/01_llm_releate/save_models/qwen3_next/pretrain', use_fast=True)
    args = TrainingArguments(output_dir='/mnt/code/zhaoxudong03/RL/verl_base_zxd/01_llm_releate/save_models/qwen3_next/result_sft', 
                            num_train_epochs=1, 
                            do_train=True, 
                            per_device_train_batch_size=8,
                            gradient_accumulation_steps=2,
                            # max_steps=15000,
                            logging_steps=1,
                            save_steps=100,
                            report_to='tensorboard',
                            save_total_limit=5,
                            bf16=True,
                            learning_rate=5e-5,
                            lr_scheduler_type='cosine',
                            dataloader_num_workers=1,
                            dataloader_pin_memory=True,
                            save_safetensors=False)    
    
    dataset = SFTDataset('/mnt/code/zhaoxudong03/RL/verl_base_zxd/01_llm_releate/data/sft_1024.jsonl', tokenizer=tokenizer, max_seq_len=1024)
    trainer = Trainer(model=model, args=args, train_dataset=dataset, tokenizer=tokenizer, data_collator=data_collator)
    # 如果是初次训练resume_from_checkpoint为false，接着checkpoint继续训练，为True
    trainer.train(resume_from_checkpoint=False)
    trainer.save_model('/mnt/code/zhaoxudong03/RL/verl_base_zxd/01_llm_releate/save_models/qwen3_next/sft')
    trainer.save_state()